﻿using UnityEngine;
using System.Collections;

public class QuitGame : MonoBehaviour {

	void OnMouseDown() {
		Application.Quit ();
	}
}
