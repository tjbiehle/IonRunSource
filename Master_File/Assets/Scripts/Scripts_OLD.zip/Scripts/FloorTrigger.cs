﻿using UnityEngine;
using System.Collections;

public class FloorTrigger : MonoBehaviour {
	public GameObject Play;
	// Use this for initialization
	void Start () 
	{
	
	}
	
	// Update is called once per frame
	void Update () 
	{
				//IN GUI PORTION OF GAME
		if(Play.activeSelf == false)
		{

		}
				//IN GAME PORTION OF GAME
		else
		{

		}
	}



}
