﻿using UnityEngine;
using System.Collections;

public class ShowCreditsScene : MonoBehaviour {

	void OnMouseDown() {
		Application.LoadLevel ("Credits");
}
}
