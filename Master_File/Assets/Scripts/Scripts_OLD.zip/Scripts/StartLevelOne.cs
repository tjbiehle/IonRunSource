﻿using UnityEngine;
using System.Collections;

public class StartLevelOne : MonoBehaviour {

	void OnMouseDown() {
		Application.LoadLevel ("Ion_Run_1");
}
}
