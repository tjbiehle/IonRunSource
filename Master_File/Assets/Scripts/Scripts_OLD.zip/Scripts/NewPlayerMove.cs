﻿#pragma strict

// This will be for curved traveling probably

using UnityEngine;
using System.Collections;

public class NewPlayerMove : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
