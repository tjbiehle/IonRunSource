﻿using UnityEngine;
using System.Collections;

public class ShowLevelSelectScene : MonoBehaviour {

	void OnMouseDown() {
		Application.LoadLevel ("Levels");
}
}
