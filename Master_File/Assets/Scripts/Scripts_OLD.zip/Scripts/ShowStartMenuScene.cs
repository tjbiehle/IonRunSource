﻿using UnityEngine;
using System.Collections;

public class ShowStartMenuScene : MonoBehaviour {

	void OnMouseDown() {
		Application.LoadLevel ("StartMenu");
}
}
