﻿using UnityEngine;
using System.Collections;

public class StartGameFromPrevious : MonoBehaviour {

	void OnMouseDown() {
		Application.LoadLevel ("Ion_Run_1");
}
}
