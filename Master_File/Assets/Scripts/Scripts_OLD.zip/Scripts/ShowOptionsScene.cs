﻿using UnityEngine;
using System.Collections;

public class ShowOptionsScene : MonoBehaviour {

	void OnMouseDown() {
		Application.LoadLevel ("Options");
}
}
