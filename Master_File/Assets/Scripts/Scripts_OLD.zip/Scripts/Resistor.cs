﻿using UnityEngine;
using System.Collections;

public class Resistor : MonoBehaviour {
	bool setval = false;
	string result = "";

	void OnMouseDown()
	{
		setval = true;

	}

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () 
	{
			/* Write to a string, . is the end statement */
		if(setval)
		{
			if(Input.GetKeyDown ("1"))
				result += "1";
			if(Input.GetKeyDown ("2"))
				result += "2";
			if(Input.GetKeyDown ("3"))
				result += "3";
			if(Input.GetKeyDown ("4"))
				result += "4";
			if(Input.GetKeyDown ("5"))
				result += "5";
			if(Input.GetKeyDown ("6"))
				result += "6";
			if(Input.GetKeyDown ("7"))
				result += "7";
			if(Input.GetKeyDown  ("8"))
				result += "8";
			if(Input.GetKeyDown ("9"))
				result += "9";
			if(Input.GetKeyDown ("0"))
				result += "0";
			if (Input.GetKeyDown ("c"))
				result = "";
			if (Input.GetKeyDown ("."))
			{
				gameObject.name = result;
				setval = false;
			}
		}
	}
}
